using UnityEngine;
using System.Collections;

public class Aspect : MonoBehaviour {
	public enum Affiliation {
		Player,
		Enemy
	}
	public Affiliation affiliation;
}
